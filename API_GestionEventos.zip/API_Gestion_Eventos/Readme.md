    RUTAS COMPROBODAS

        USERS

POST Registro de usuario 
http://localhost:3500/user/registeruser

     {
    "username": "Dayana",
    "password": "12345"
}
{
    "collection":"users"
}

POST Login de usuario
http://localhost:3500/user/login
            {
    "username": "Usuario3",
    "password": "12345"
}
GET Devuelve una lista de usuarios
http://localhost:3500/user/listusers





        EVENTS

POST Crear Evento
http://localhost:3500/events/createevent

GET Obtener evento por ID
http://localhost:3500/events/getbyid/67543bc6fb7c7f458d18f1ce

GET Obtener evento por tipo
http://localhost:3500/events/getbytype?type=Patinaje

DELETE Eliminar evento por ID
http://localhost:3500/events/delete/67543bc6fb7c7f458d18f1ce




