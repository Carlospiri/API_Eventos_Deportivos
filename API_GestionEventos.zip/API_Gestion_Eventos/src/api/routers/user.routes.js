const express= require("express");
const router = express.Router();
const{
    registerUser, 
    getUsers, 
    loginUser,
    deleteUser
}= require("../controllers/user.controller");

const  {loginCheck }=require("../../utils/middleware")

router.get("/listusers", getUsers, loginCheck)
router.post("/registeruser", registerUser);
router.post("/login", loginUser);
router.delete("/deleteuser", deleteUser, loginCheck)


module.exports = router;
