const express = require('express');
const { 
    createEvent,
    updateEvent, 
    deleteEvent,
     getByDate,
     getById,
     getByType 
    } = require('../controllers/events.controller');
    
const router = express.Router();
const {loginCheck}=require("../../utils/middleware")

router.post("/createevent", createEvent, loginCheck,)
router.put("/updateevent/:id",  updateEvent, loginCheck)
router.get("/getbyid/:id",getById)
router.get("/getbytype",getByType)
//router.get("/getbydate/:tipoDeporte",getByDate)
router.delete("/delete/:id", deleteEvent, loginCheck)




module.exports = router;