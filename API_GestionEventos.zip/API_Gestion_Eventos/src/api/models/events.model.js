const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  descripcion: { type: String, required: true },
  fecha: { type: Date, required: true },
  ubicacion: { type: String, required: true },
  tipoDeporte: { type: String, required: true },
  organizador: { type: String },
});

module.exports = mongoose.model('Event', eventSchema);