const mongoose = require("mongoose");
const Schema= mongoose.Schema;
const bcrypt = require('bcrypt');

const userSchema = new Schema(
    {
    username:{type:String, require:true},
    password:{type:String, require: true},
    
},
{
    collection:"users",
   
}
);
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
  });

const Users = mongoose.model("users", userSchema)
module.exports = Users;