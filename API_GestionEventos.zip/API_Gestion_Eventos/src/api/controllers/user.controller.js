const Users = require("../models/user.model")
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const registerUser = async(req,res)=> {
  try {
    const data = req.body;
    const newUser = new Users(data);
    const createdUser = await newUser.save();
    return res.json({message:"usuario creado", data: createdUser})

  } catch (error) {
    console.log(error)
  }
};
const loginUser = async (req,res) => {
  const { username, password } = req.body

  const user = await Users.findOne({ username })
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ message: "Contrasena o usuario incorrecto" });
  }
  const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: "1h" })
  res.json({ message:"Login correcto", token });
  
}
const getUsers = async(req,res)=>{
    try {
        const listUsers= await Users.find()
        res.json({success: true, list: listUsers})
        
    } catch (error) {
        console.log(error)
    }
}

const updateUser = async (req,res) => {
  
}

const deleteUser = async (req,res) => {
  const { id } = req.params
  
  try {

    const user = await Users.findByIdAndDelete(id)
    
    if (!user) {

      return res.status(404).json({ message: "Usuario no encontrado" })
    }

    return res.status(200).json({ message: "Usuario eliminado con exito" })
  } catch (error) {
   
    console.log(error)
    res.status(500).json({ message: "Error al eliminar el usuario", error })
  }
  
}
//Exportar las funciones para poder usarla en otro lados
module.exports = {registerUser,loginUser, getUsers, deleteUser};