const Events = require ("../models/events.model")

const createEvent = async (req,res) => {
    try {
        const data = req.body;
        const newEvent = new Events(data);
        const createdevent = await newEvent.save();

        if(!data){
          return res.status(404).json({msg:"Falta informacion en el body"})
        }
        return res.json({message:"Evento Creado", data: createdevent})
    
      } catch (error) {
        
      }
    
}
const updateEvent = async (req,res) => {
  const {eventId} = req.params
  const updatedData = req.body
  try {
    const eventUpdated = await Events.findByIdAndUpdate(eventId,updatedData)
    if(!Event){
      return res.status(404).json({msg:"evento no encontrado"})
    }
    res.json(eventUpdated)
    
  } catch (error) {
    
  }
    
}
const deleteEvent = async (req,res) => {
  const { id } = req.params

  try {
      const event = await Events.findByIdAndDelete(id)
      if (!event) {
          return res.status(404).json({ message: "Evento no encontrado" })
      }
      res.status(200).json({ message: "Evento eliminado con exito" })
  } catch (error) {
      res.status(500).json({ message: "Error al eliminar el evento", error })
  }
}

const getByType = async (req, res) => {
  const { type } = req.query  
  if (!type) {
      return res.status(400).json({ msg: "Falta el tipo de evento" })
  }

  try {
      
      const events = await Events.find({ tipoDeporte: type })

      if (events.length === 0) {
          return res.status(404).json({ msg: "No se encontraron este tipo de eventos" }); 
      }

      return res.status(200).json(events);  
  } catch (error) {
      return res.status(500).json({ msg: "Error al obtener los eventos", error })  
  }
};
//Hacer
const getByDate = async (req,res) => {
    
}
const getById = async (req,res) => {
    const {id} = req.params
    try {
      const event = await Events.findById(id)

      if(!event){
        return res.status(404).json({msg:"evento no encontrado"})
      }
      return res.status(200).json(event)
      
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener el evento', error });
      
    }
}



module.exports = {createEvent,updateEvent, deleteEvent, getByDate,getById,getByType}