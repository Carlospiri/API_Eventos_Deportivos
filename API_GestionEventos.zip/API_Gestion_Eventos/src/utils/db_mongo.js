const mongoose = require("mongoose")

const connectDB = async()=>{
    try {
        const db = await mongoose.connect(process.env.DBURL)
        const {name, host}= db.connection;
        console.log("nombre de la base de datos "+ name + " y servidor " + host)


    } catch (error) {
        console.log(error)
    }
};

module.exports = connectDB;