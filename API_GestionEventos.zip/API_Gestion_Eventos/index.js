const express = require("express"); // decirle que use el modulo express
require("dotenv").config();// configuro mi servidor para usar variables de entorno
const connectDB = require('./src/utils/db_mongo');
const routerUser = require("./src/api/routers/user.routes")
const routerEvent = require("./src/api/routers/event.router")
connectDB();

const server = express();
server.use(express.json());
PORT = process.env.PORT,

server.use("/user", routerUser)
server.use("/events", routerEvent)

server.listen(process.env.PORT, ()=>{

    console.log("server runing at " + PORT )
});